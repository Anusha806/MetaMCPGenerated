import os
import requests
from prettytable import PrettyTable

# Load API key from environment variable
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

API_KEY = os.getenv('WEATHER_API_KEY')
if API_KEY is None:
    raise ValueError("Missing environment variable: WEATHER_API_KEY")

# Define constants
BASE_URL = "https://api.openweathermap.org/data/2.5/onecall"
LATITUDE = 16.5062  # Latitude for Vijayawada, India
LONGITUDE = 80.6480  # Longitude for Vijayawada, India
EXCLUDE = "minutely,hourly"  # We only want daily data

def fetch_weather_forecast(api_key):
    """Fetches the 7-day weather forecast for Vijayawada, India."""
    params = {
        'lat': LATITUDE,
        'lon': LONGITUDE,
        'exclude': EXCLUDE,
        'units': 'metric',  # Use metric units
        'appid': api_key
    }
    
    try:
        response = requests.get(BASE_URL, params=params)
        response.raise_for_status()  # Raise an error for bad responses
    except requests.exceptions.RequestException as e:
        raise SystemExit(f"Error fetching weather data: {e}")

    return response.json()

def display_forecast(forecast):
    """Displays the weather forecast in a readable format."""
    table = PrettyTable()
    table.field_names = ["Date", "High (°C)", "Low (°C)", "Conditions"]

    for day in forecast['daily']:
        date = day['dt']  # Unix timestamp
        high = day['temp']['max']
        low = day['temp']['min']
        conditions = day['weather'][0]['description']

        table.add_row([date, high, low, conditions])

    print(table)

def main():
    """Main function to run the weather forecast tool."""
    weather_data = fetch_weather_forecast(API_KEY)
    display_forecast(weather_data)

if __name__ == "__main__":
    main()