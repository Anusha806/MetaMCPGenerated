import os
import requests
import sys
from datetime import datetime, timedelta

# Fetching API key and base URL from environment variables
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

API_KEY = os.getenv('WEATHER_API_KEY')
BASE_URL = os.getenv('WEATHER_API_URL', 'https://api.openweathermap.org/data/2.5/onecall')

# Check if the API key is provided
if not API_KEY:
    sys.exit("Error: No API key found. Please set the WEATHER_API_KEY environment variable.")

def fetch_weather_forecast(lat, lon):
    """
    Fetch the 7-day weather forecast for the given latitude and longitude.

    :param lat: Latitude of the location
    :param lon: Longitude of the location
    :return: A dictionary containing weather data or None if an error occurred.
    """
    try:
        url = f"{BASE_URL}?lat={lat}&lon={lon}&exclude=hourly,minutely&appid={API_KEY}&units=metric"
        response = requests.get(url)

        # Raise an exception for HTTP errors
        response.raise_for_status()

        data = response.json()
        return data
    except requests.exceptions.RequestException as e:
        print(f"Error fetching weather data: {e}")
        return None

def display_forecast(forecast):
    """
    Display the 7-day weather forecast in a readable format.

    :param forecast: Weather data containing daily forecasts
    """
    if 'daily' not in forecast:
        print("No daily forecast data available.")
        return

    print(f"{'Date':<12} {'High (°C)':<12} {'Low (°C)':<12} {'Description':<20} {'Severe Alerts'}")
    print("=" * 70)

    for day in forecast['daily']:
        date = datetime.fromtimestamp(day['dt']).strftime('%Y-%m-%d')
        temp_high = day['temp']['max']
        temp_low = day['temp']['min']
        description = day['weather'][0]['description']
        alerts = "Yes" if 'alerts' in forecast and forecast['alerts'] else "No"
        
        print(f"{date:<12} {temp_high:<12} {temp_low:<12} {description:<20} {alerts}")

def main():
    # Vijayawada, India coordinates
    vijayawada_lat = 16.5062
    vijayawada_lon = 80.6480

    forecast_data = fetch_weather_forecast(vijayawada_lat, vijayawada_lon)
    
    if forecast_data:
        display_forecast(forecast_data)

if __name__ == "__main__":
    main()