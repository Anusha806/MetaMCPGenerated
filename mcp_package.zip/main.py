import os
import requests
import json
from prettytable import PrettyTable

# Load API key and base URL from environment variables
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

API_KEY = os.getenv('WEATHER_API_KEY')
BASE_URL = os.getenv('WEATHER_API_URL', 'https://api.openweathermap.org/data/2.5/')

# Check if the API key is provided
if not API_KEY:
    raise ValueError("Environment variable 'WEATHER_API_KEY' is required but not set.")

def fetch_weather_forecast(city: str) -> dict:
    """
    Fetch the 7-day weather forecast for the given city.

    Args:
    city (str): Name of the city to fetch weather for.

    Returns:
    dict: A dictionary containing weather forecast data.

    Raises:
    Exception: If there is an issue with the API request or data retrieval.
    """
    try:
        # Make API request
        url = f"{BASE_URL}onecall?lat=16.5062&lon=80.6480&exclude=current,minutely,hourly&appid={API_KEY}&units=metric"
        response = requests.get(url)
        response.raise_for_status()  # Raise an error for bad responses
        return response.json()  # Parse and return JSON data
    except requests.exceptions.HTTPError as http_err:
        raise Exception(f"HTTP error occurred: {http_err}")
    except Exception as err:
        raise Exception(f"An error occurred: {err}")

def display_forecast(data: dict):
    """
    Display the 7-day weather forecast in a readable format.

    Args:
    data (dict): The weather forecast data.
    """
    try:
        table = PrettyTable()
        table.field_names = ["Date", "High (°C)", "Low (°C)", "Description", "Severe Weather Alert"]

        for day in data['daily']:
            # Extract weather details
            date = day['dt']
            high_temp = day['temp']['max']
            low_temp = day['temp']['min']
            description = day['weather'][0]['description']
            alerts = data.get('alerts', [])
            alert_message = alerts[0]['description'] if alerts else "None"

            # Append row to the table
            table.add_row([date, high_temp, low_temp, description, alert_message])

        print(table)  # Print the formatted table
    except KeyError as key_err:
        raise Exception(f"Missing key in data: {key_err}")
    except Exception as err:
        raise Exception(f"An error occurred while displaying the forecast: {err}")

if __name__ == "__main__":
    city_name = "Vijayawada"  # City for which to fetch the weather
    weather_data = fetch_weather_forecast(city_name)
    display_forecast(weather_data)