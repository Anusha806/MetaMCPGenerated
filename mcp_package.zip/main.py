import os
import requests
import json
from prettytable import PrettyTable

# Load environment variables
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

API_KEY = os.getenv('WEATHER_API_KEY')
if not API_KEY:
    raise ValueError("Missing environment variable: WEATHER_API_KEY")

BASE_URL = "https://api.openweathermap.org/data/2.5/onecall"

def fetch_weather_forecast(lat, lon):
    """
    Fetch the 7-day weather forecast using OpenWeatherMap API.

    Args:
        lat (float): Latitude of the location.
        lon (float): Longitude of the location.

    Returns:
        dict: A dictionary containing weather forecast data.
    """
    params = {
        'lat': lat,
        'lon': lon,
        'exclude': 'current,minutely,hourly',
        'units': 'metric',
        'appid': API_KEY
    }
    
    try:
        response = requests.get(BASE_URL, params=params)
        response.raise_for_status()  # Raise an error for bad responses
        return response.json()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Error fetching weather data: {e}")

def display_forecast(data):
    """
    Display weather forecast in a readable table format.

    Args:
        data (dict): Weather forecast data from API.
    """
    if 'daily' not in data:
        print("No daily forecast data available.")
        return
        
    table = PrettyTable()
    table.field_names = ["Date", "High (°C)", "Low (°C)", "Conditions", "Severe Weather Alerts"]

    for day in data['daily']:
        date = day['dt']
        high_temp = day['temp']['max']
        low_temp = day['temp']['min']
        conditions = day['weather'][0]['description']
        alerts = get_weather_alerts(data)

        table.add_row([date, high_temp, low_temp, conditions, alerts])

    print(table)

def get_weather_alerts(data):
    """
    Retrieve severe weather alerts if available.

    Args:
        data (dict): Weather forecast data from API.

    Returns:
        str: A string of alerts or 'None' if no alerts are present.
    """
    return ", ".join(alert['description'] for alert in data.get('alerts', [])) or 'None'

def main():
    """
    Main function to execute the weather forecast tool.
    """
    # Coordinates for Vijayawada, India
    latitude = 16.5062
    longitude = 80.6480

    try:
        weather_data = fetch_weather_forecast(latitude, longitude)
        display_forecast(weather_data)
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()