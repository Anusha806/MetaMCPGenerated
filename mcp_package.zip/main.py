import os
import requests

from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class WeatherFetcher:
    def __init__(self):
        # Load API key from environment variable, raise an error if not found
        self.api_key = os.getenv('WEATHER_API_KEY')
        if not self.api_key:
            raise ValueError("Missing environment variable: WEATHER_API_KEY")

        # API endpoint for the weather service
        self.api_endpoint = os.getenv('WEATHER_API_ENDPOINT', 'http://api.openweathermap.org/data/2.5/weather')

    def fetch_weather(self, city: str) -> dict:
        """
        Fetch weather information for a given city.

        Args:
            city (str): The city name for which to fetch the weather.

        Returns:
            dict: Weather information retrieved from the API response.
        """
        params = {
            'q': city,
            'appid': self.api_key,
            'units': 'metric'  # Use metric units
        }
        
        try:
            response = requests.get(self.api_endpoint, params=params)
            response.raise_for_status()  # Raise an error for bad responses
            return response.json()  # Return the JSON response as a dictionary
        except requests.exceptions.HTTPError as http_err:
            print(f"HTTP error occurred: {http_err}")  # Print HTTP error
        except requests.exceptions.RequestException as err:
            print(f"Error occurred: {err}")  # Print any other request error
        except Exception as e:
            print(f"An error occurred: {e}")  # Print generic error

        return {}

if __name__ == "__main__":
    fetcher = WeatherFetcher()
    
    city_name = "Vijayawada"  # Change as needed or make this dynamic
    weather_data = fetcher.fetch_weather(city_name)

    if weather_data:
        print(weather_data)
    else:
        print("Failed to retrieve weather data.")